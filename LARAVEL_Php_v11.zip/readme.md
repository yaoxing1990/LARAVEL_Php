# Mini Social Network

·	The app is a simple social network, which supports the current user to upload/edit his own posts as well as to view/like/dislike other users’ posts. The backend is based on PHP framework Laravel 5.3. User information and posts are stored in MySQL database. The client side is based on jQuery, and requests are sent to backend through AJAX.
